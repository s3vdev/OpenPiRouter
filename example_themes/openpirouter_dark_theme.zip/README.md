# OpenPiRouter Dark Theme

Modern dark theme with glassmorphism effects and blue/purple accents.

## Installation
1. Upload this ZIP via the Theme Manager
2. Click on the theme preview to activate it

## Customization
Edit template.html to customize the dashboard appearance.
All HTML, CSS, and JavaScript can be modified.

