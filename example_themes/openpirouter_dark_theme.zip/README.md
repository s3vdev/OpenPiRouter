# OpenPiRouter Dark Theme V2

## Theme System V2
This theme uses the new V2 architecture where:
- Themes contain ONLY HTML structure and CSS styling
- JavaScript is automatically provided by the system
- No need to update themes when system features change!

## Features
- Dark slate background (#0f172a)
- Glassmorphism cards with backdrop blur
- Indigo/Violet gradients
- Glowing hover effects
- Optimized for night use

## Installation
1. Upload via Theme Manager in OpenPiRouter Dashboard
2. Click to activate

## Customization
Edit CSS in template.html to change:
- Background gradient colors
- Card transparency and blur
- Border glow colors
- Text colors

Keep all IDs and class names unchanged!
