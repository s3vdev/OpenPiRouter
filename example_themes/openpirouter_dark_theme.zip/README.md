# OpenPiRouter Theme

## Installation
1. Upload this ZIP file via the Theme Manager in OpenPiRouter Dashboard
2. Click on the theme preview to activate it

## Structure
- template.html: Main dashboard template
- screenshot.png: Theme preview image
- meta.json: Theme metadata

## Customization
Edit template.html to customize the dashboard appearance.
All HTML, CSS, and JavaScript can be modified.
