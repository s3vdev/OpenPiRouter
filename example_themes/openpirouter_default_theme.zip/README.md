# OpenPiRouter Default Theme

Standard OpenPiRouter Dashboard Theme with purple gradient and light design.

## Installation
1. Upload this ZIP via the Theme Manager
2. Click on the theme preview to activate it

## Customization
Edit template.html to customize the dashboard appearance.
All HTML, CSS, and JavaScript can be modified.

