# OpenPiRouter Default Theme V2

## Theme System V2
This theme uses the new V2 architecture where:
- Themes contain ONLY HTML structure and CSS styling
- JavaScript is automatically provided by the system
- No need to update themes when system features change!

## Installation
1. Upload via Theme Manager in OpenPiRouter Dashboard
2. Click to activate

## Structure
- template.html: HTML + CSS (NO JavaScript)
- screenshot.png: Preview image
- meta.json: Theme metadata

## Customization
Edit CSS in template.html to change:
- Colors (purple gradient, text colors)
- Fonts and spacing
- Card styles and shadows
- Button styles

Keep all IDs and class names unchanged!
